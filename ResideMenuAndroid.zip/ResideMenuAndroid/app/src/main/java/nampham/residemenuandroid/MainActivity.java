package nampham.residemenuandroid;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.special.ResideMenu.ResideMenu;
import com.special.ResideMenu.ResideMenuItem;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private ResideMenu resideMenu;
    private ResideMenuItem itemHome;
    private ResideMenuItem itemSetting;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        taomenuReside();




    }
    // ham nay dung de tao menu Reside

    public void taomenuReside(){
        resideMenu=new ResideMenu(this);
        //khoi tao mot resideMenu ngay tren cai activity nay

        resideMenu.setBackground(R.drawable.menu_background);
        resideMenu.setScaleValue(0.6f);
        //độ rộng của ResideMenu
        resideMenu.attachToActivity(this);

        //khoi tao item menu

        itemHome=new ResideMenuItem(this,R.drawable.icon_home,"Home");
        itemSetting=new ResideMenuItem(this,R.drawable.icon_settings,"Setting");
        //minh se cho chung năm bên
        resideMenu.addMenuItem(itemHome,ResideMenu.DIRECTION_RIGHT);
        resideMenu.addMenuItem(itemSetting,ResideMenu.DIRECTION_RIGHT);

        itemHome.setOnClickListener(this);
        itemSetting.setOnClickListener(this);
        //chung ta se tạo hành động click nhé

        findViewById(R.id.title_bar_left_menu).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resideMenu.openMenu(ResideMenu.DIRECTION_LEFT);
            }
        });
        findViewById(R.id.title_bar_right_menu).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resideMenu.openMenu(ResideMenu.DIRECTION_RIGHT);
            }
        });


    }

    @Override
    public void onClick(View view) {

        if(view==itemHome){
            Toast.makeText(MainActivity.this, "Ban vua click item Home", Toast.LENGTH_SHORT).show();

        }else if(view==itemSetting){
            Toast.makeText(MainActivity.this, "Ban vua click item Setting", Toast.LENGTH_SHORT).show();
        }

    }
}
